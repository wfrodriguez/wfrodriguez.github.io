/* Hard-coded conf.h for ws3270 */

#define LIBX3270DIR	"."

#define X3270_IPV6	1
